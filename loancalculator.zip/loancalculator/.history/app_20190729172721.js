document.getElementById('loan-form').addEventListener('submit',calculateResults);

function 