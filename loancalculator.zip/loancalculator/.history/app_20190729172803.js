document.getElementById('loan-form').addEventListener('submit',calculateResults);

function calculateResults(e){
console.log('calculating....')
e.preventDefault();
}