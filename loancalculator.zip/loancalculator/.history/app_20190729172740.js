document.getElementById('loan-form').addEventListener('submit',calculateResults);

function calculateResults(e){

e.prevent
}